const Discord = require("discord.js");
const client = new Discord.Client();
const CanalCerrado = new Discord.MessageAttachment("https://i.ibb.co/QDZFjSP/Canal-Cerrado.png");
const CanalAbierto = new Discord.MessageAttachment("https://i.ibb.co/0D0jvxF/Canal-Abierto.png");

client.on("ready", () => {
    console.log("FBI Preparado");
 });

 //inv --> https://discord.io/fbirencarnadosRP
 
 client.on("message", (message) => {
   if(message.content.startsWith("/normas")) {
     message.channel.send("La normativa de nuestro servidor esta aquí: https://docs.google.com/document/d/1haHCypiwD4GDMgP_ygQHcDwvIW-W1oSYD5KuoPSUC1k/edit?usp=sharing");
   }
 
 });

 client.on("message", (message) => {
  if(message.content.startsWith("/inv")) {
    message.channel.send("Invita a alguien usando este link: https://discord.io/fbirencarnadosRP");
  }
 });

  client.on("message", (message) => {
    if(message.content.startsWith("hola")) {
      message.channel.send("!Hola <@"+ message.author + ">");
    }
  }); 

  client.on("message", (message) => {
    if(message.content.startsWith("Hola")) {
      message.channel.send("!Hola <@"+ message.author + ">");
    }
  });

  client.on("message", (message) => {
    if(message.content.startsWith("buenos días")) {
      message.channel.send("Igualmente. <@"+ message.author + ">");
    }
  }); 

  client.on("message", (message) => {
    if(message.content.startsWith("Buenos Días")) {
      message.channel.send("Igualmente. <@"+ message.author + ">");
    }
  }); 
  
  client.on("message", (message) => {
    if(message.content.startsWith("Buenos días")) {
      message.channel.send("Igualmente. <@"+ message.author + ">");
    }
  }); 

  client.on("message", message => {
    if(message.content.startsWith("/Cerrar.canal")){
      if(message.member.roles.cache.find(rol => rol.id === "842151849587245097")){
        message.channel.send(CanalCerrado);
        message.delete();
      }
      else{
        message.channel.send("Este comando es exclusivo para el Staff");
      }
    }
  })

  client.on("message", message => {
    if(message.content.startsWith("/Abrir.canal")){
      if(message.member.roles.cache.find(rol => rol.id === "842151849587245097")){
        message.channel.send(CanalAbierto);
        message.delete();
      }
      else{
        message.channel.send("Este comando es exclusivo para el Staff");
      }
    }
  })

 client.login("ODM3MDc0NDYxMTUxNzIzNTMw.YInQVw.1oaFu2RsNB0qHKttFHl7lkwkcB8");